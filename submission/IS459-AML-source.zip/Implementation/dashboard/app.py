"""Read-only visualization of one immutable published release."""
import json,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pandas as pd
import streamlit as st
from dashboard.bank_labels import load_bank_names, segment_label
from dashboard.data import q1_query,q1_trend_query,run_query,get_case,evidence_csv,wilson,dimension_query,full_evidence_archive
from dashboard.presentation import PATTERNS,esc,kpis,period,exposure_chart,monitoring_lead,priority_card,rule_card
from dashboard.case_catalog import CaseCatalog
from dashboard.case_connections import link_payments, render_graph, transfer_links
from dashboard.case_queue import render_case_queue
from dashboard.ml_replay import render_explorer, replay_evaluation, replay_explorer
from dashboard.fresh_bq2 import batch_caption, fresh_bq2, fresh_evaluation, local_bq2_workspace
from dashboard.trends import range_options,date_window,daily_population,population_total,coverage_counts,LOW_DAILY_VOLUME,endpoint_comparison,trend_chart
from pipeline.bq2_release import BQ2_CURRENT_URI
from pipeline.release import ACCOUNT,REGION,load_current,verify_ref

ml_replay_pin=os.environ.get('TRACE_ML_REPLAY_PIN')
bq2_pointer=os.environ.get('TRACE_BQ2_POINTER')

st.set_page_config(page_title='TRACE | AML intelligence',page_icon='◈',layout='wide',initial_sidebar_state='expanded')
st.markdown('<style>'+Path(__file__).with_name('styles.css').read_text()+'</style>',unsafe_allow_html=True)
local_bq2_mirror=os.environ.get('TRACE_BQ2_LOCAL_MIRROR')
if local_bq2_mirror:
    local_bq2_workspace(Path(local_bq2_mirror), bq2_pointer or BQ2_CURRENT_URI)
    st.stop()

@st.cache_resource
def clients(profile,instance):
    import boto3
    if not profile and not instance:raise ValueError('Select a verified project profile or explicitly enable the EC2 instance role.')
    session=boto3.Session(profile_name=profile or None,region_name=REGION)
    if session.client('sts').get_caller_identity()['Account']!=ACCOUNT:raise ValueError('Wrong AWS project account')
    return session.client('s3'),session.client('athena')

@st.cache_data(ttl=300,max_entries=64)
def query_cached(release_id,sql):return run_query(athena,sql)

@st.cache_data(ttl=300,max_entries=4)
def case_cached(release_data,row):return get_case(s3,release_data,row)

@st.cache_resource(max_entries=2, show_spinner=False)
def case_catalog(release_data):return CaseCatalog(s3,release_data)

@st.cache_data(max_entries=256, show_spinner=False)
def queued_cases(release_data,snapshot,pattern,page=None):return case_catalog(release_data).queue(snapshot,pattern,page)

@st.cache_data(max_entries=4)
def bank_names_cached(path, modified_ns):return load_bank_names(path)


def bank_names_for_display():
    packaged=Path(__file__).with_name('bank_names.csv')
    default=packaged if packaged.exists() else Path(__file__).resolve().parents[2]/'Ibm_dataset_medium/HI-Medium_accounts.csv'
    lookup=Path(os.environ.get('AML_BANK_NAMES_CSV',str(default)))
    try:return bank_names_cached(str(lookup),lookup.stat().st_mtime_ns)
    except (OSError,ValueError):
        st.warning('Bank names are unavailable. Bank IDs remain visible.')
        return {}

profile=os.environ.get('AML_AWS_PROFILE','');instance=os.environ.get('AML_USE_INSTANCE_ROLE')=='1'
try:
    with st.spinner('Connecting to the verified published release…'):
        s3,athena=clients(profile,instance)
        if 'release' not in st.session_state:st.session_state.release=load_current(s3)
        release=st.session_state.release
except Exception as error:
    st.title('Connect your published analysis')
    st.info('Start this workspace with your verified project profile.')
    st.code('bash Implementation/scripts/start_local_dashboard.sh YOUR_PROJECT_PROFILE')
    st.caption(str(error));st.stop()

with st.sidebar:
    st.markdown('<div class="brand"><strong>trace.</strong><span>AML<br>INTELLIGENCE</span></div><div class="eyebrow">YOUR WORKSPACE</div>',unsafe_allow_html=True)
    page=st.radio('Workspace',['Monitoring','Case explorer','Evaluation','Release & provenance'],format_func=lambda x:{'Monitoring':'Monitoring overview','Case explorer':'Connected cases','Evaluation':'Evaluation & coverage','Release & provenance':'Release & provenance'}[x],label_visibility='collapsed',key='workspace_page')
    st.divider()
    st.caption('Synthetic data. Human judgement.')
    st.caption('Published results · Read-only workspace')
    st.caption('Historical labels describe exposure. Connected cases are investigation leads.')
st.markdown('<div class="workspace-bar"><span>Workspace / <b>'+esc(page)+'</b></span><span class="release-pill">Published release · '+esc(release['release_id'])+'</span></div>',unsafe_allow_html=True)


def caption(text):st.markdown('<div class="context">'+esc(text)+'</div>',unsafe_allow_html=True)


def cards(items):st.markdown(kpis(items),unsafe_allow_html=True)


def select_filter(*args,**kwargs):
    return st.selectbox(*args,persist_state='session',**kwargs)


def refresh_data():
    try:updated=load_current(s3)
    except Exception as error:
        st.error('Refresh failed; the previous release is still selected. '+str(error));return
    st.session_state.release=updated;st.session_state.pop('prepared_archive',None);st.rerun()


def monitoring():
    st.markdown('<div class="eyebrow">01 / COMPLIANCE MANAGEMENT</div>',unsafe_allow_html=True)
    st.title('Monitoring overview')
    caption('See where historical exposure outweighs transaction volume.')
    dates=sorted(set(release['q1']['dates']))
    with st.popover('Reporting filters',icon=':material/tune:'):
        st.caption('All counts and baselines use these same filters.')
        if st.button('Refresh data',icon=':material/refresh:',key='refresh_monitoring'):refresh_data()
        preset=select_filter('Date range',range_options(dates),index=1,key='q1_range')
        custom_start=custom_end=None
        if preset=='Custom dates':
            for key in ('q1_start','q1_end'):
                if key in st.session_state and st.session_state[key] not in dates:del st.session_state[key]
            a,b=st.columns(2)
            custom_start=a.selectbox('From date',dates,persist_state='session',index=0,key='q1_start')
            custom_end=b.selectbox('Through date',dates,persist_state='session',index=len(dates)-1,key='q1_end')
        side='payment'
        currencies=[r['currency'] for r in query_cached(release['release_id'],dimension_query(release,side))]
        choice=select_filter('Currency',['All currencies']+currencies,key='q1_currency',help='Currencies are ordered by transaction count across the published release, busiest first. Filters payment currency. All currencies combines counts and rates, with no combined monetary total.')
        currency=None if choice=='All currencies' else choice
        grain=select_filter('Compare',['bank','bank_pair','segment','format'],format_func=lambda x:{'bank':'Banks overall','format':'Payment formats','bank_pair':'Bank-to-bank routes','segment':'Bank-to-bank route + payment format'}[x],key='q1_grain')
        fmt=select_filter('Payment format',['All','ACH','Cash','Cheque','Credit Card','Reinvestment','Wire','Bitcoin'],key='q1_format')
        support=1000
        st.caption('Ranked segments require at least 1,000 payments. Low-support rows remain available in the details.')
    try:start,end=date_window(dates,preset,custom_start,custom_end)
    except ValueError as error:st.warning(str(error));return
    caption(period(start,end)+' · '+('All currencies' if currency is None else 'Payment currency: '+currency)+' · '+('All formats' if fmt=='All' else fmt)+' · Minimum '+f'{support:,}'+' payments')
    caption('Latest published date: '+period(dates[-1],dates[-1]).split(' – ')[0]+' · Rolling windows end on that date, not today.')
    caption('Published: '+release.get('created_at_utc','Unavailable')+' · Historical exposure uses available labels; newly ingested payments may await labels.')
    with st.spinner('Loading daily published counts…'):
        trend_rows=query_cached(release['release_id'],q1_trend_query(release,start,end,currency,side,None if fmt=='All' else fmt))
    daily=daily_population(trend_rows,start,end,dates,release['q1'].get('day_coverage'));n,l,rate=population_total(daily)
    count=lambda value:f'{value:,}' if value is not None else 'Not available'
    sender_bank=None
    if grain in ('bank_pair','segment'):
        bank_rows=query_cached(release['release_id'],q1_query(release,start,end,currency,side,'bank',None if fmt=='All' else fmt,support))
        names=bank_names_for_display()
        options=[str(row['sender_bank']) for row in bank_rows]
        sender_key='q1_sender_'+str(currency)+'_'+fmt
        if st.session_state.get(sender_key) not in [None]+options:st.session_state.pop(sender_key,None)
        sender_bank=select_filter('Sending bank',[None]+options,format_func=lambda x:'All sending banks' if x is None else segment_label({'sender_bank':x},names),key=sender_key)
        st.caption('Bank choices cover up to 500 banks in this selection. Daily totals remain overall; route comparisons use the selected sending bank.')
    with st.spinner('Loading published segment comparisons…'):
        rows=query_cached(release['release_id'],q1_query(release,start,end,currency,side,grain,None if fmt=='All' else fmt,support,sender_bank=sender_bank))
    if not rows:
        st.info('No transactions match the selected reporting window.');return
    frame=pd.DataFrame(rows)
    for col in ['n','l','baseline_n','baseline_l']:frame[col]=pd.to_numeric(frame[col])
    for col in ['rate','lift']:frame[col]=pd.to_numeric(frame[col],errors='coerce')
    baseline_n=int(frame.iloc[0].baseline_n);baseline_l=int(frame.iloc[0].baseline_l)
    baseline_rate=f'{baseline_l/baseline_n:.4%}' if baseline_n else 'Not measurable'
    names=bank_names_for_display() if grain!='format' else {}
    if grain=='bank':
        st.caption('Banks overall: each payment counts once under its sending bank, including within-bank transfers.')
    elif grain!='format':
        st.caption('Sending bank → Receiving bank: payments from accounts at the first bank to accounts at the second. Each route can include many accounts. IDs distinguish banks that share a name.')
    frame['group']=frame.apply(lambda r:segment_label(r,names),axis=1)
    records=frame.to_dict('records');lead=monitoring_lead(records)
    priorities=sum(r['support']=='supported' and pd.notna(r['lift']) and r['lift']>1 for r in records)
    cards([('Transactions in scope',count(n),'All currencies' if currency is None else 'Selected payment currency'),('Historically labelled',count(l),'Known labels, not new detections'),('Labelled rate',f'{rate:.4%}' if rate is not None else 'Not measurable','Σ labels ÷ Σ payments'),('Above-baseline groups',f'{priorities:,}','Supported groups in the ranking preview')])
    st.subheader('Payment types relative to their size')
    st.caption('Compare each payment type’s share of all payments with its share of historical labelled laundering. Relative risk above 1× means a higher labelled rate than the same filtered population.')
    type_rows=rows if grain=='format' and sender_bank is None else query_cached(release['release_id'],q1_query(release,start,end,currency,side,'format',None if fmt=='All' else fmt,support))
    if type_rows:
        types=pd.DataFrame(type_rows)
        for col in ['n','l','baseline_n','baseline_l','rate','lift']:types[col]=pd.to_numeric(types[col],errors='coerce')
        types['group']=types['payment_format']
        type_chart=exposure_chart(types.to_dict('records'),'Risk lift')
        if type_chart is not None:st.plotly_chart(type_chart,width='stretch',config={'displayModeBar':False})
        else:st.info('No supported payment types have positive historical labelled exposure in this selection.')
        types['Traffic share']=types.apply(lambda r:f'{r.n/r.baseline_n:.2%}' if r.baseline_n else 'Not measurable',axis=1)
        types['Labelled share']=types.apply(lambda r:f'{r.l/r.baseline_l:.2%}' if r.baseline_l else 'Not measurable',axis=1)
        types['Labelled rate']=types.rate.map(lambda value:f'{value:.4%}')
        types['Relative risk']=types.apply(lambda r:f'{r.lift:.2f}×' if r.support=='supported' and pd.notna(r.lift) else 'Not ranked',axis=1)
        types=types.rename(columns={'payment_format':'Payment type','n':'Transactions','l':'Historical labels','support':'Support'})
        st.dataframe(types[['Payment type','Transactions','Historical labels','Traffic share','Labelled share','Labelled rate','Relative risk','Support']],hide_index=True,width='stretch')
        st.caption('Payment types use the overall date, payment-currency and format filters, independently of a selected sending bank. Low-support types remain visible and unranked. Historical labels describe exposure, not new detections.')
    st.divider()
    chart_col,insight_col=st.columns([2,1],gap='large')
    with chart_col:
        st.subheader({'bank':'Banks overall','bank_pair':'Bank-to-bank routes','segment':'Routes by payment format','format':'Payment formats'}[grain])
        mode=st.segmented_control('Chart view',['Volume vs rate','Risk lift'],default='Volume vs rate',required=True,label_visibility='collapsed',key='q1_chart',persist_state='session')
        chart=exposure_chart(records,mode)
        if chart is None:st.info('No supported groups have positive labelled exposure in this selection.')
        else:
            st.plotly_chart(chart,width='stretch',config={'displayModeBar':False})
            st.caption('Up to 10 supported groups by lift · Hover for exact counts · Log volume axis in volume/rate view · 1× lift matches the selected baseline.')
    with insight_col:
        st.markdown(priority_card(lead),unsafe_allow_html=True)
    st.subheader('Monitoring priorities')
    caption('Selected-window ranking · '+period(start,end)+f' · Baseline: {baseline_n:,} payments / {baseline_l:,} labels / '+baseline_rate)
    summary=frame.head(10).copy()
    summary['Rate']=summary.rate.map(lambda x:f'{x:.4%}')
    summary['Lift']=summary.apply(lambda r:f'{r.lift:.2f}×' if r.support=='supported' and pd.notna(r.lift) else 'Not ranked',axis=1)
    summary['Traffic share']=summary.n.map(lambda value:f'{value/baseline_n:.1%}' if baseline_n else 'Not measurable')
    summary=summary.rename(columns={'group':'Segment','n':'Transactions','l':'Labels','support':'Support'})
    st.dataframe(summary[['Segment','Transactions','Labels','Rate','Lift','Traffic share','Support']],hide_index=True,width='stretch')
    st.caption(f'Showing {len(summary):,} of {len(frame):,} returned groups (query cap: 500). Support ≥ 1,000 payments. Low-support rows are inspectable counts, never ranked priorities.')
    inspect_key='q1_inspect_'+grain
    stored_group=st.session_state.get(inspect_key,0)
    if not isinstance(stored_group,int) or not 0<=stored_group<len(frame):st.session_state.pop(inspect_key,None)
    selected_group=select_filter('Inspect a segment',range(len(frame)),format_func=lambda i:frame.iloc[i]['group'],key='q1_inspect_'+grain)
    inspected=frame.iloc[selected_group]
    with st.expander('Selected segment details',expanded=False):
        st.write(str(inspected['group']))
        cards([('Segment payments',f'{int(inspected.n):,}','Denominator for this segment'),('Historical labels',f'{int(inspected.l):,}','Historical association'),('Support',str(inspected.support).replace('_',' ').title(),'Required minimum: 1,000 payments')])
        if currency is not None:st.write('Transferred amount: '+str(inspected.selected_currency_amount)+' '+currency+' (payment currency)')
        else:st.caption('Select a currency to see transferred amounts.')
        st.caption('Descriptive 95% interval: '+' – '.join(f'{x:.4%}' for x in wilson(int(inspected.l),int(inspected.n)))+'. Related payments may violate independence. Transferred value is not unique criminal proceeds.')
    with st.expander('Explore exact counts, amounts and uncertainty',expanded=False):
        display=frame.copy();display['Rate']=display.rate.map(lambda x:f'{x:.4%}');display['Lift']=display.apply(lambda r:f'{r.lift:.2f}×' if r.support=='supported' and pd.notna(r.lift) else 'Not ranked',axis=1);display['Descriptive 95% interval']=display.apply(lambda r:' – '.join(f'{x:.4%}' for x in wilson(int(r.l),int(r.n))),axis=1)
        display=display.rename(columns={'group':'Segment','n':'Transactions','l':'Labels','support':'Support','selected_currency_amount':str(currency)+' amount (paid)'})
        amount_columns=[currency+' amount (paid)'] if currency is not None else []
        st.dataframe(display[['Segment','Transactions','Labels','Rate','Lift','Support']+amount_columns+['Descriptive 95% interval']],hide_index=True,width='stretch')
        st.caption('Up to 500 groups. Low-support groups are unranked. Select a currency to see exact transferred amounts. Intervals are descriptive; related payments may violate independence. Transferred value is not unique criminal proceeds.')

    st.divider()
    st.subheader('How exposure changed')
    coverage=coverage_counts(daily)
    if coverage['missing']:st.warning(f"{coverage['missing']} dates are absent from the published coverage. They remain gaps, not zero-count days.")
    if coverage['partial']:st.warning(f"{coverage['partial']} dates have explicitly reported partial coverage. Counts are retained; comparisons are provisional.")
    if coverage['low_volume']:st.info(f"{coverage['low_volume']} low-volume days: fewer than {LOW_DAILY_VOLUME:,} payments in this filtered population. Rates can be unstable. Low volume alone does not establish incomplete or bad data.")
    st.plotly_chart(trend_chart(daily),width='stretch',config={'displayModeBar':False})
    st.caption('Daily counts, rate and total traffic use the same payment-currency and format filter. Hover for exact values. Rates are calculated from counts; a day with no payments has no measurable rate.')
    comparison=endpoint_comparison(daily)
    if comparison:st.caption(comparison)
    with st.expander('Daily counts behind the trend'):
        st.dataframe(pd.DataFrame(daily).rename(columns={'date':'Date','n':'Transactions','l':'Labelled laundering','rate':'Laundering rate','coverage':'Day completeness','low_volume':'Low volume'}),hide_index=True,width='stretch',column_config={'Laundering rate':st.column_config.NumberColumn(format='percent')})
    if coverage['unknown']:st.caption('Whole-day completeness metadata was not supplied for some published dates. Publication alone does not certify a full day of source coverage.')


def explorer():
    st.markdown('<div class="eyebrow">02 / CONNECTED-ACCOUNT INVESTIGATION</div>',unsafe_allow_html=True)
    st.title('Follow the connections.')
    caption('Explainable structures. Traceable evidence. A starting point for investigation.')
    case_lists=['Published rules']
    if ml_replay_pin:case_lists.append('Historical ML shortlist')
    if bq2_pointer:case_lists.insert(0,'Fresh batch ML shortlist')
    if len(case_lists)>1:
        case_list=st.radio('Case list',case_lists,horizontal=True,key='ml_replay_source')
        if case_list=='Fresh batch ML shortlist':
            fresh=fresh_bq2(s3,bq2_pointer)
            render_explorer(s3,fresh,batch_caption(fresh))
            return
        if case_list=='Historical ML shortlist':
            replay_explorer(s3,ml_replay_pin)
            return
    q2=release['q2']
    snapshots={item['window_end']:item for item in q2.get('snapshots') or [q2]}
    ends=sorted(snapshots)
    snapshot_col,pattern_col=st.columns(2,gap='small')
    choice=ends[-1]
    with snapshot_col:
        snapshot_mode=select_filter('Snapshot view',['Latest published','All snapshots','Custom snapshot'],key='q2_snapshot_mode')
        if snapshot_mode=='All snapshots':
            choice=None
        elif snapshot_mode=='Custom snapshot':
            if 'q2_snapshot' in st.session_state and st.session_state.q2_snapshot not in ends:del st.session_state['q2_snapshot']
            choice=select_filter('Daily snapshot cutoff',ends,index=len(ends)-1,format_func=lambda x:period(x,x).split(' – ')[0],key='q2_snapshot')
    with pattern_col:
        pattern=select_filter('Pattern',['All',*PATTERNS],format_func=lambda x:PATTERNS.get(x,'All patterns'),key='q2_pattern')
    pattern_label=PATTERNS.get(pattern,'All patterns')
    if choice is None:
        caption(f'{len(snapshots)} published snapshots · Overlapping windows · {pattern_label}')
    else:
        snapshot=snapshots[choice]
        caption(period(snapshot['window_start'],snapshot['window_end'])+' · End exclusive · Dataset-local time · '+pattern_label)
        if not snapshot.get('history_complete',True):st.warning('Earlier history is incomplete for this snapshot.')
    selected_pattern=None if pattern=='All' else pattern
    scope=(release['release_id'],choice,selected_pattern)
    with st.spinner('Finding published cases…'):total=queued_cases(release,choice,selected_pattern)
    if not total:st.info('No cases match this pattern.');return
    queue,case_view=st.columns([1,2.25],gap='medium')
    with queue:
        selected=render_case_queue(scope,total,lambda _release,snapshot,pattern,page:queued_cases(release,snapshot,pattern,page))
    snapshot=snapshots[selected['snapshot']]
    with case_view:
        if choice is None:
            caption('Case window: '+period(snapshot['window_start'],snapshot['window_end'])+' · End exclusive · Dataset-local time')
            if not snapshot.get('history_complete',True):st.warning('Earlier history is incomplete for this snapshot.')
        with st.spinner('Opening case evidence…'):case,raw=case_cached(release,selected)
        cards([('Pattern',PATTERNS.get(case['pattern_type'],case['pattern_type']),'Structural lead, not proof'),('Accounts',f"{case['participant_count']:,}",'Distinct participating bank/accounts'),('Evidence payments',f"{case['evidence_transaction_count']:,}",'Complete evidence is downloadable')])
        caption('Case '+case['case_id'][:16]+'… · '+PATTERNS.get(case['pattern_type'],case['pattern_type'])+' · '+str(case['rule_version']))
        st.markdown(rule_card(case),unsafe_allow_html=True)
        labels=st.toggle('Show account labels',value=len(case['nodes'])<=20,key='labels_'+case['case_id'],persist_state='session',help='Hover or click an account for the full identifier. Large graphs start without labels to avoid overlap.')
        link_key='evidence_link_'+case['case_id']
        arrow_rows=render_graph(case,labels,s3,release['release_id'],link_key)
        if snapshot.get('cycle_excluded_nodes_above_degree',0):st.caption(f"Cycle coverage excludes {snapshot['cycle_excluded_nodes_above_degree']:,} high-degree accounts; fan evidence remains complete.")
    accounts,evidence=st.tabs(['Accounts & entities','Evidence preview'])
    with accounts:
        fields=['bank','account','entity_name','entity_id','entity_unknown'];available=[k for k in fields if any(k in n for n in case['nodes'])]
        st.dataframe(pd.DataFrame(case['nodes'])[available].rename(columns={'bank':'Bank','account':'Account','entity_name':'Entity','entity_id':'Entity ID','entity_unknown':'Unknown mapping'}),hide_index=True,width='stretch')
        st.caption('Account preview from the case bundle. Full participants and evidence references remain in the case manifest.')
    with evidence:
        preview=case['transactions'][:200]
        relationships=transfer_links(case)
        if relationships:
            selected_link=st.selectbox('Transfer link',[None,*relationships],
                format_func=lambda key:'All transfer links' if key is None else relationships[key][0],
                key=link_key)
            if selected_link is not None:
                label,count=relationships[selected_link]
                preview=arrow_rows if arrow_rows is not None else link_payments(s3,release['release_id'],case,*selected_link,count)
                st.caption(f'Showing {len(preview):,} of {count:,} payments for {label}.')
        st.dataframe(pd.DataFrame(preview).rename(columns={'event_time':'Time','source_id':'Source ID','sender_bank':'Sending bank','sender_account':'Sending account','receiver_bank':'Receiving bank','receiver_account':'Receiving account','amount_paid':'Amount paid','payment_currency':'Paid currency','amount_received':'Amount received','receiving_currency':'Received currency','payment_format':'Format'}),hide_index=True,width='stretch')
        st.caption('Up to 200 preview rows. Amounts retain exact strings and separate paid/received currencies. Downloads contain all evidence, including distinct parallel payments.')
    st.subheader('Keep the evidence')
    st.download_button('Download case manifest' if case.get('schema_version',1)>=2 else 'Download complete case JSON',raw,file_name=case['case_id']+'.json',mime='application/json')
    if case.get('schema_version',1)>=2:
        if st.button('Prepare complete evidence download',icon=':material/download:'):
            with st.spinner('Verifying all evidence chunks…'):st.session_state['prepared_archive']=(release['release_id'],case['case_id'],full_evidence_archive(s3,case))
        archive=st.session_state.get('prepared_archive')
        if archive and archive[:2]==(release['release_id'],case['case_id']):st.download_button('Download all evidence chunks',archive[2],file_name=case['case_id']+'.zip',mime='application/zip')
    else:st.download_button('Download all supporting transactions',evidence_csv(case),file_name=case['case_id']+'.csv',mime='text/csv')
    with st.expander('Rule, scope and full case identity'):
        st.write(case['interpretation']);st.write('Rule: '+case['rule_version']);st.write('Case: '+case['case_id']);st.write('Snapshot cutoff: '+snapshot['snapshot_cutoff']);st.caption('A structural cycle does not establish a chronological return of identical funds.')


def evaluation():
    if bq2_pointer:fresh_evaluation(fresh_bq2(s3,bq2_pointer))
    if ml_replay_pin:replay_evaluation(s3,ml_replay_pin)
    st.markdown('<div class="eyebrow">03 / EVALUATION & COVERAGE</div>',unsafe_allow_html=True)
    st.title('Understand the limits.')
    caption('Separate connected-pattern recovery from individual-payment classification.')
    metrics=verify_ref(s3,release['evaluation']['metrics']);window=metrics.get('scoring_window')
    if window:caption('Holdout: '+period(window['start_inclusive'],window['end_exclusive'])+' · Start inclusive, end exclusive · Dataset-local time')
    tx=metrics['detector_transaction_metrics'];annotated=metrics['annotation_metrics']
    cards([('Eligible payments',f"{tx['population']:,}",'Full eligible holdout population' if window else 'Declared evaluation population'),('Labelled positives',f"{tx['positive_labels']:,}",'Historical evaluation labels'),('Precision',f"{tx['precision']:.3%}" if tx.get('precision') is not None else 'Not measurable','Labels among alerted payments'),('Recall',f"{tx['recall']:.2%}" if tx.get('recall') is not None else 'Not measurable','Positive labels covered')])
    st.subheader('Individual-payment comparison')
    comparisons=[]
    for label,key in [('Connected cases','detector_transaction_metrics'),('Matched-volume amount','amount_baseline_transaction_metrics'),('Development-frozen amount','frozen_amount_baseline_transaction_metrics')]:
        if key not in metrics:continue
        item=metrics[key];comparisons.append({'Method':label,'Alerted payments':item['unique_alerted_transactions'],'Precision':f"{item['precision']:.3%}" if item.get('precision') is not None else 'Not measurable','Recall':f"{item['recall']:.2%}" if item.get('recall') is not None else 'Not measurable'})
    st.dataframe(pd.DataFrame(comparisons),hide_index=True,width='stretch')
    baseline=metrics.get('amount_baseline_transaction_metrics',{})
    if all(tx.get(k) is not None and baseline.get(k) is not None and baseline[k]>tx[k] for k in ('precision','recall')):st.info('The amount baseline performs better on individual-payment precision and recall. Connected cases add explainable relationship evidence, but do not outperform it on these measures.')
    st.subheader('Eligible pattern recovery')
    recovery=annotated.get('attempt_recovery');coverage=annotated.get('amount_baseline_coverage_80pct');gain=metrics.get('recovery_improvement_percentage_points');target=metrics.get('improvement_target_met')
    cards([('Eligible annotations',f"{annotated['eligible_attempts']:,}",'Supported attempts in this population'),('Attempt recovery',f'{recovery:.2%}' if recovery is not None else 'Not measurable','Correct type and ≥80% core evidence'),('Recovery gain',f'{gain:.2f} pp' if gain is not None else 'Not measurable','Against matched-volume amount coverage')])
    if 'improvement_target_met' in metrics:st.write('Frozen five-percentage-point target: **'+('Met' if target is True else 'Unmet' if target is False else 'Not measurable')+'**')
    if coverage is not None:st.caption(f'Matched-volume amount baseline covers at least 80% of evidence for {coverage:.2%} of eligible attempts.')
    with st.expander('How to interpret these findings',expanded=True):
        st.write('Recovery applies only to eligible supported annotations. It does not mean every laundering event was recovered. Unannotated cases are not automatically false positives.')
        st.write('Development, holdout and sparse-tail periods stay separate. Calibration is frozen before holdout; rules are not retuned against these results.')
        for limitation in metrics.get('limitations',[]):st.write(limitation)
        st.caption('Labels and annotations enter offline evaluation only. Structural leads are not proof of laundering.')


def provenance():
    st.markdown('<div class="eyebrow">04 / RELEASE & PROVENANCE</div>',unsafe_allow_html=True)
    st.title('Know your source.')
    caption('Every view reads the same verified published release. A refresh switches only after the new manifest passes validation.')
    cards([('Source','IBM HI-Medium','Synthetic transaction dataset'),('Connection','Published outputs','Read-only Athena and private S3'),('Time policy','Dataset-local','Exclusive snapshot cutoffs; timezone unspecified')])
    st.write('Release: '+release['release_id'])
    st.write('Dataset: '+release['dataset_version'])
    st.write('Preparation run: '+release['run_id'])
    st.caption('Q1: '+period(min(release['q1']['dates']),max(release['q1']['dates']))+' · Q2 snapshots: '+period(release['q2']['window_start'],release['q2']['window_end']))
    st.caption(release['timestamp_policy'])
    st.write('Published manifest → matching summaries and immutable case evidence → separate offline evaluation.')
    st.caption('Display caps do not remove stored evidence. Q2 case discovery does not read historical labels, Q1 scores or evaluation answers. Failed refreshes retain the prior selected release.')
    for warning in release['warnings']:st.info(warning)
    if st.button('Refresh published release',key='refresh_provenance'):refresh_data()


try:
    if page=='Monitoring':monitoring()
    elif page=='Case explorer':explorer()
    elif page=='Evaluation':evaluation()
    else:provenance()
except Exception as error:st.error('This view could not load. '+str(error))

st.divider()
st.caption('TRACE / AML research workspace · Synthetic IBM data · Historical exposure and structural leads')
with st.expander('Published release & scope'):
    st.write('Release: '+release['release_id']);st.caption('Dataset: '+release['dataset_version']+' · Preparation: '+release['run_id'])
    st.caption('Q1: '+period(release['q1']['dates'][0],release['q1']['dates'][-1])+' · Q2 snapshots: '+period(release['q2']['window_start'],release['q2']['window_end']))
    st.caption(release['timestamp_policy'])
    for warning in release['warnings']:st.write(warning)
    if st.button('Refresh published release'):refresh_data()
