"""Synthetic app interactions: active-page reads and consistent Q1 filters."""
import json,os,sys,unittest
from pathlib import Path
from unittest.mock import Mock,patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from streamlit.testing.v1 import AppTest


class DashboardNavigationTests(unittest.TestCase):
    def test_pages_only_load_their_own_inputs_and_currency_changes_query_population(self):
        window={'window_start':'2022-09-01T00:00:00','window_end':'2022-09-02T00:00:00','snapshot_cutoff':'2022-09-02T00:00:00','case_count':1,'history_complete':False}
        release={'release_id':'synthetic-ui','dataset_version':'fixture','run_id':'fixture','release_kind':'pilot','q1':{'dates':['2022-09-01']},'q2':{**window,'analysis_id':'fixture','snapshots':[window],'bundles':'s3://fixture/'},'catalog':{'database':'fixture','q1_table':'q1','q2_table':'q2'},'evaluation':{'metrics':{}},'timestamp_policy':'dataset-local','warnings':['Synthetic fixture']}
        nodes=[{'node_id':json.dumps([str(i),str(i)]),'bank':str(i),'account':str(i),'entity_id':'entity-'+str(i),'entity_name':'Fixture entity','entity_unknown':False} for i in range(3)]
        case={'pattern_type':'cycle_3','case_id':'a'*64,'rule_version':'fixture','participant_count':3,'evidence_transaction_count':3,'schema_version':3,'nodes':nodes,'edges':[{'source':nodes[i]['node_id'],'target':nodes[(i+1)%3]['node_id'],'transaction_count':1} for i in range(3)],'transactions':[{'source_id':'fixture:'+str(i),'amount_paid':'0.47209301','payment_currency':'US Dollar','amount_received':'0.47000000','receiving_currency':'Euro'} for i in range(3)],'interpretation':'Synthetic structural lead'}
        sqls=[]
        def query(client,sql):
            sqls.append(sql)
            if ' AS currency' in sql:return [{'currency':'US Dollar'}]
            if 'GROUP BY event_date' in sql:return [{'event_date':'2022-09-01','n':'2000','l':'3'}]
            if 'GROUP BY sender_bank)' in sql:return [{'sender_bank':'11','n':'2000','l':'3','baseline_n':'2000','baseline_l':'3','rate':'.0015','lift':'1','support':'supported','selected_currency_amount':'0.47209301'}]
            if 'GROUP BY sender_bank, receiver_bank)' in sql:return [{'sender_bank':'11','receiver_bank':'214','n':'2000','l':'3','baseline_n':'2000','baseline_l':'3','rate':'.0015','lift':'1','support':'supported','selected_currency_amount':'0.47209301'}]
            return [{'payment_format':'ACH','n':'2000','l':'3','baseline_n':'2000','baseline_l':'3','rate':'.0015','lift':'1','support':'supported','selected_currency_amount':'0.47209301'}]
        tx={'population':2000,'positive_labels':3,'unique_alerted_transactions':1,'precision':None,'recall':None}
        metrics={'detector_transaction_metrics':tx,'annotation_metrics':{'eligible_attempts':0,'attempt_recovery':None},'limitations':['Fixture only']}
        session=Mock();session.client.return_value.get_caller_identity.return_value={'Account':'160885259244'}
        catalog=Mock()
        catalog.queue.side_effect=lambda snapshot,pattern,page=None:1 if page is None else [
            {'case_id':case['case_id'],'pattern_type':'cycle_3','participant_count':3,
             'evidence_transaction_count':3,'snapshot':window['window_end']}]
        with patch.dict(os.environ,{'AML_AWS_PROFILE':'synthetic-test','AML_USE_INSTANCE_ROLE':''}),patch('boto3.Session',return_value=session),patch('pipeline.release.load_current',return_value=release),patch('pipeline.release.verify_ref',return_value=metrics) as metric_read,patch('dashboard.data.run_query',side_effect=query),patch('dashboard.data.get_case',return_value=(case,b'{}')) as case_read,patch('dashboard.case_catalog.CaseCatalog',return_value=catalog) as index_read:
            app=AppTest.from_file(str(Path(__file__).resolve().parents[1]/'dashboard/app.py')).run(timeout=20)
            self.assertEqual(len(app.exception),0);self.assertEqual(len(app.error),0);self.assertFalse(case_read.called);self.assertFalse(metric_read.called)
            self.assertFalse(index_read.called)
            self.assertEqual(app.selectbox(key='q1_currency').value,'All currencies')
            self.assertEqual(app.selectbox(key='q1_grain').value,'bank')
            self.assertTrue(any(x.value=='Payment types relative to their size' for x in app.subheader))
            headings=[x.value for x in app.subheader]
            self.assertLess(headings.index('Payment types relative to their size'),headings.index('Banks overall'))
            type_table=next(x.value for x in app.dataframe if 'Payment type' in x.value.columns)
            self.assertEqual(type_table['Payment type'].iloc[0],'ACH')
            self.assertTrue({'Traffic share','Labelled share','Labelled rate','Relative risk'}.issubset(type_table.columns))
            self.assertFalse(any(x.label=='Currency side' for x in app.selectbox))
            self.assertFalse(any("payment_currency='US Dollar'" in x for x in sqls))
            self.assertFalse(any(any('amount' in str(col).lower() for col in x.value.columns) for x in app.dataframe))
            self.assertFalse(any('Volume isn’t the whole story.' in x.value for x in app.subheader))
            app.selectbox(key='q1_currency').set_value('US Dollar').run(timeout=20)
            self.assertTrue(any("payment_currency='US Dollar'" in x for x in sqls))
            self.assertEqual(next(x.value for x in app.dataframe if 'US Dollar amount (paid)' in x.value.columns)['US Dollar amount (paid)'].iloc[0],'0.47209301')
            app.selectbox(key='q1_grain').set_value('bank_pair').run(timeout=20)
            app.selectbox(key='q1_sender_US Dollar_All').set_value('11').run(timeout=20)
            self.assertEqual(len(app.error),0);self.assertTrue(any("sender_bank='11'" in x for x in sqls));self.assertFalse(case_read.called)
            app.radio(key='workspace_page').set_value('Case explorer').run(timeout=20)
            self.assertEqual(len(app.exception),0);self.assertEqual(len(app.error),0);self.assertTrue(case_read.called);self.assertFalse(metric_read.called)
            self.assertTrue(index_read.called)
            app.radio(key='workspace_page').set_value('Evaluation').run(timeout=20)
            self.assertEqual(len(app.exception),0);self.assertEqual(len(app.error),0);self.assertTrue(metric_read.called)
            self.assertTrue(any('Not measurable' in x.value for x in app.markdown))
            before=len(sqls)
            app.radio(key='workspace_page').set_value('Release & provenance').run(timeout=20)
            self.assertEqual(len(app.exception),0);self.assertEqual(len(app.error),0);self.assertEqual(len(sqls),before)
            self.assertTrue(any('fixture' in x.value for x in app.markdown))
            app.radio(key='workspace_page').set_value('Monitoring').run(timeout=20)
            self.assertEqual(app.selectbox(key='q1_currency').value,'US Dollar')
            self.assertEqual(app.selectbox(key='q1_sender_US Dollar_All').value,'11')
            app.selectbox(key='q1_grain').set_value('format').run(timeout=20)
            self.assertEqual(len(app.exception),0);self.assertEqual(len(app.error),0)
            app.selectbox(key='q1_currency').set_value('All currencies').run(timeout=20)
            self.assertEqual(len(app.exception),0);self.assertEqual(len(app.error),0)
            # Browser-persisted selectors may restore an old index as a string.
            app.session_state['q1_inspect_bank']='0'
            app.selectbox(key='q1_grain').set_value('bank').run(timeout=20)
            self.assertEqual(len(app.exception),0);self.assertEqual(len(app.error),0)
            self.assertEqual(len(app.error),0)


if __name__=='__main__':unittest.main()
