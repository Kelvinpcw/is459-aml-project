"""Read-only investigation application."""
